<html>
<head>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
</head>

<body>
<h1>SUBMIT FORM</h1>
  
<form action="javascript:void(0)" method='POST' id="ajaxform">
<?php echo csrf_field(); ?>
    NAME : <input type="text" name ="name" placeholder ="Name" autocomplete="off"></input><br><br>
    <span id = "name_err"></span>
    <?php echo e(method_field('post')); ?>

    EMAIL : <input type="email" name ="email" placeholder ="Email" ></input><br><br>
    <span id = "email_err"></span>
    PINCODE : <input type="pin" name ="pin" placeholder ="pincode" ></input><br><br>
    <!-- <span id = "pin_err"></span>
    <span id = "submit_message"></span> -->
    <input type="submit" name ="submit" placeholder ="submit" id="sub">
</form>

<?php if($errors->any()): ?>                    
<div id = "error">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($errors); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<script>
// TO SEE ITS HOW IT IS WORKING, INSPECT=>NETWORK=>HEADERS & PREVIEW & RESPONSE
$(document).ready(function(){
    $('#sub').click(function(e){
        e.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/control",
            method: 'POST',
            // SERIALIZE ARRAY IS USED BECAUSE IT IS IN FORM OF ARRAY.
            data: JSON.stringify($('#ajaxform').serializeArray()),
            contentType:  'application/json; charset=utf-8',
            
            success: function(response){
                // SHOWS MESSAGE IF SUCCESS
                // alert("success");
                document.getElementById("ajaxform").reset(); 
            },
            error: function(err){
                // SHOWS MESSAGE IF ERROR
                // alert("error");
                document.getElementById("ajaxform").reset();
            }
            });
        });
});
</script> 
</body>
</html>
<?php /**PATH C:\composer\laravel_hosting\resources\views/main.blade.php ENDPATH**/ ?>