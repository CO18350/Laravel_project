<?php

namespace App\Http\Controllers;

use App\Models\Task_model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use app\Http\Controllers\Auth;
use Validator;
use App\Traits\wsctrait;

class WebServicesController extends Controller
{
    
    use wsctrait;
}
