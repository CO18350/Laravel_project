<html>
<h1>SUBMIT FORM</h1>
<form action='controller' method='post'>
    NAME : <input type="text" name ="name" placeholder ="Name" autocomplete="off"></input><br><br>
    {{@csrf_field()}}
    {{ method_field('post')}}
    EMAIL : <input type="email" name ="email" placeholder ="Email" ></input><br><br>
    PINCODE : <input type="pin" name ="pin" placeholder ="pincode"></input><br><br>
    <input type="submit" name ="submit" placeholder ="submit">
</form>
@if($errors->any())                     <!-- To display errors in form validation -->
<div>
    <ul>
        @foreach($errors->all() as $errors)
        <li>{{$errors}}</li>
        @endforeach
    </ul>
</div>
@endif
</html>