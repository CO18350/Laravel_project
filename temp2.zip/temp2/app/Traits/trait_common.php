<?php
namespace App\traits;
trait trait_common{
    public function tr(){
        $store = new Task_model;
            $store->name = $req->get('name');
            $store->email = $req->get('email');
            $store->pincode = $req->get('pin');
            $name = $store->name;
            $email = $store->email;
            $pincode = $store->pincode;
            
            $store->save();
            echo "Saved";
            # TO MAKE LOG STATEMENT
            Log::alert('EMAIL SENT',['EMAIL'=>$email]);
            return response()->json(['status: 1, msg : saved successfully'],201);
    }
}
?>