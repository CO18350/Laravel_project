<?php
namespace App\Traits;
use Illuminate\Http\Request;
use Validator;
trait wsctrait{
    public function create(Request $req){  
        $validation = Validator::make($req->all(),[                 #rules for validation
            'email'=>'required|unique:data,email',
            'name'=>'required|unique:data,name',
            'pin'=>'required|min:6'
        ]);    
        if($validation->fails()){
            // return response()->json(['Message_Error_occured'=>$validation->errors()], 401);
            return response()->json(['status : 0 , error '=>$validation->errors()], 401);
            // Log::alert('Email cannot be sent');
        }
        else{
            $store = new Task_model;
            $store->name = $req->get('name');
            $store->email = $req->get('email');
            $store->pincode = $req->get('pin');
            $name = $store->name;
            $email = $store->email;
            $pincode = $store->pincode;
            
            $store->save();
            echo "Saved";
            # TO MAKE LOG STATEMENT
            Log::alert('EMAIL SENT',['EMAIL'=>$email]);
            return response()->json(['status: 1, msg : saved successfully'],201);
        }
}
}
?>




