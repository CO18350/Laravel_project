<?php

namespace App\Http\Controllers;

use App\Models\Task_model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use app\Http\Controllers\Auth;
use Validator;
use App\Traits\trait_common;

class ATGController extends Controller
{
    use trait_common;
    }

    