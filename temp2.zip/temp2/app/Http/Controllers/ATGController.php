<?php

namespace App\Http\Controllers;

use App\Models\Task_model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use app\Http\Controllers\Auth;
use Validator;

class ATGController extends Controller
{
        public function account(Request $req){  
            $validation = Validator::make($req->all(),[                 #rules for validation
            'email'=>'required|unique:data,email',
            'name'=>'required|unique:data,name',
            'pin'=>'required|min:6'
        ]);    
        
            if($validation->fails()){
                // return response()->json(['Message_Error_occured'=>$validation->errors()], 401);
                return response()->json(['status : 0 , error '=>$validation->errors()], 401);
                // Log::alert('Email cannot be sent');
            }
            else{
                $store = new Task_model;
                $store->name = $req->get('name');
                $store->email = $req->get('email');
                $store->pincode = $req->get('pin');
                $name = $store->name;
                $email = $store->email;
                $pincode = $store->pincode;
                
                $store->save();
                echo "Saved";
                # TO MAKE LOG STATEMENT
                Log::alert('EMAIL SENT',['EMAIL'=>$email]);
                return response()->json(['status: 1, msg : saved successfully'],201);
            }
        // }
            // return response()->json(['message'=>'saved successfully'],201);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Task_model  $task_model
     * @return \Illuminate\Http\Response
     */
    public function show(Task_model $task_model)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Task_model  $task_model
     * @return \Illuminate\Http\Response
     */
    public function edit(Task_model $task_model)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Task_model  $task_model
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Task_model $task_model)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Task_model  $task_model
     * @return \Illuminate\Http\Response
     */
    public function destroy(Task_model $task_model)
    {
        //
    }
}
