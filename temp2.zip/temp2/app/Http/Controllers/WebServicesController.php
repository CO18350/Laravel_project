<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task_model;
use Illuminate\Support\Facades\Log;
use app\Http\Controllers\Auth;
use App\User;
use Validator;
use App\Traits\wsctrait;

class WebServicesController extends Controller
{
    use wsctrait;
}
