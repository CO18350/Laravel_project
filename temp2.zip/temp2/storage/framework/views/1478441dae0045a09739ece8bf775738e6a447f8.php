<html>
<h1>SUBMIT FORM</h1>
<form action='controller' method='post'>
    NAME : <input type="text" name ="name" placeholder ="Name" autocomplete="off"></input><br><br>
    <?php echo e(@csrf_field()); ?>

    <?php echo e(method_field('post')); ?>

    EMAIL : <input type="email" name ="email" placeholder ="Email" ></input><br><br>
    PINCODE : <input type="pin" name ="pin" placeholder ="pincode"></input><br><br>
    <input type="submit" name ="submit" placeholder ="submit">
</form>
<?php if($errors->any()): ?>                     <!-- To display errors in form validation -->
<div>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($errors); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
</html><?php /**PATH C:\composer\temp2\resources\views/main.blade.php ENDPATH**/ ?>