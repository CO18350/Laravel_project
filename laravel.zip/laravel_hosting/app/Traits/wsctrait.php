<?php
namespace App\Traits;

use Validator;
use App\Models\Task_model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use app\Http\Controllers\Auth;
use Illuminate\Database\Eloquent\Model;
trait wsctrait{
    public function create(Request $req){ 
        
        // $payload = json_decode(request()->getContent()); 
        // $result = json_decode($req->data, true);
        // return print_r($payload);
        // $payload = (json_decode(file_get_contents("php://input"), true));
        //  echo ($payload['name']);
        $validation = Validator::make($req->all(),[                
            'email'=>'required|unique:data,email',
            'name'=>'required|unique:data,name',
            'pin'=>'required|min:6'
        ]);    
        if($validation->fails()){
            // RETURN RESPONSE IN JSON FORMAT
            return response()->json(['status : 0 , error '=>$validation->errors()], 401);
        }
        else{
            $store = new Task_model;
            $store->name = ($req->get('name'));
            $store->email = ($req->get('email'));
            $store->pincode = ($req->get('pin'));
            $name = $store->name;
            $email = $store->email;
            $pincode = $store->pincode;
            // echo $email;
                // $store = new Task_model;
                // $store->name = $payload['name'];               #To get value from array obtained because it is object
                // $store->email = $payload['email'];              # 0 FOR TOKEN, 1 FOR NAME, 2 FOR TYPE POST, 3 FOR EMAIL, 4 FOR PASSWORD
                // $store->pincode = $payload['pin'];            # $req->get('input name') => if input data without ajax.
                // $name = $store->name;
                // $email = $store->email;
                // $pincode = $store->pincode;  
            $store->save();
            echo "Saved";
            # TO MAKE LOG STATEMENT
            Log::alert('EMAIL SENT',['EMAIL'=>$email]);
            return response()->json(['status: 1, msg : saved successfully'],201);
        }
}
}
?>




