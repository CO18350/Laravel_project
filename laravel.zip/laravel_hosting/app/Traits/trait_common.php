<?php
namespace App\Traits;
use App\Models\Task_model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use app\Http\Controllers\Auth;
use Validator;
use Illuminate\Database\Eloquent\Model;
trait trait_common{
    public function account(Request $req){  

        // TO GET CONTENT IN JSON FORMAT THROUGH AJAX
        $payload = json_decode(request()->getContent());
        // VALIDATION RULES
            $validation = Validator::make(
                array('name' => $payload[1]->value),
                array('name' => 'required|unique:data,name') );
            $email_validation= Validator::make(
                array('email' => $payload[3]->value),
                array('email' => 'required|unique:data,email') );
            $pin_validation = Validator::make(
                    array('pin' => $payload[4]->value),
                    array('pin' => 'required|min:6') );
            $errors = "{".$validation->errors('name').", ".$email_validation->errors('email')." ,".$pin_validation->errors('pin')."}";
            // TO CHECK THE VALIDATION ERRORS
            // $errors = json_decode($errors);
            if($email_validation->fails() || $pin_validation->fails()|| $validation->fails() ){
                return response()->json(['status' => 0 , 'error'=>$errors],401);
            }
            else{     
                $store = new Task_model;
                $store->name = $payload[1]->value;               #To get value from array obtained because it is object
                $store->email = $payload[3]->value;              # 0 FOR TOKEN, 1 FOR NAME, 2 FOR TYPE POST, 3 FOR EMAIL, 4 FOR PASSWORD
                $store->pincode = $payload[4]->value; 
                $name = $store->name;
                $email = $store->email;
                $pincode = $store->pincode;                     # $req->get('input name') => if input data without ajax. 
                $store->save();
                // echo "Saved";

                # TO MAKE LOG STATEMENT
                Log::alert('EMAIL SENT',['EMAIL'=>$email]);
                return response()->json(['status'=> 1, 'msg'=> 'saved successfully'],201);
    }
        
    }
} 
?>