<html>
<head>
<meta name="csrf-token" content="{{ csrf_token() }}"> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>  
</head>

<body>
<h1>SUBMIT FORM</h1>
  
<form action="javascript:void(0)" method='POST' id="ajaxform">
@csrf
    NAME : <input type="text" name ="name" placeholder ="Name" autocomplete="off"></input><br><br>
    <span id = "name_err"></span>
    {{ method_field('post')}}
    EMAIL : <input type="email" name ="email" placeholder ="Email" ></input><br><br>
    PINCODE : <input type="pin" name ="pin" placeholder ="pincode" ></input><br><br>
    <input type="submit" name ="submit" placeholder ="submit" id="sub">
</form>

@if($errors->any())                    
<div id = "error">
    <ul>
        @foreach($errors->all() as $errors)
        <li>{{$errors}}</li>
        @endforeach
    </ul>
</div>
@endif
<script>
// TO SEE ITS HOW IT IS WORKING, INSPECT=>NETWORK=>HEADERS & PREVIEW & RESPONSE
$(document).ready(function(){
    $('#sub').click(function(e){
        e.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/control",
            method: 'POST',
            // SERIALIZE ARRAY IS USED BECAUSE IT IS IN FORM OF ARRAY.
            data: JSON.stringify($('#ajaxform').serializeArray()),
            contentType:  'application/json; charset=utf-8',
            success: function(data){
                // TO PRINT DATA
                console.log(data);
                // TO ALERT, JSON_STRINGIFY IS USED
                $js_succ = JSON.stringify(data);
                alert($js_succ);
                // TO RESET THE FORM
                document.getElementById("ajaxform").reset(); 
            },
            error: function(data){
                // .responseText => attribute of data
                $resp = data.responseText;
                // TO CONVERT OUTPUT IN JSON FORMAT
                $js = JSON.parse($resp);
                console.log($js);
                // TO SHOW ON ALERT, JSON_STRINGIFY IS USED
                $js_err = JSON.stringify($js,null,13);
                alert($js_err);
                // TO RESET THE FORM
                document.getElementById("ajaxform").reset();
            }
            });
        });
});
</script> 
</body>
</html>
